<?php

namespace App\Controller;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

use App\Dao\ClubeDAO;
use App\Mapper\ClubeMapper;
use App\Service\ClubeService;
use App\Util\MensagemErro;

use \PDOException;

class ClubeController
{

	private ClubeDAO $clubeDAO;
	private ClubeMapper $clubeMapper;
	private ClubeService $clubeService;

	public function __construct()
	{
		$this->clubeDAO = new ClubeDAO();
		$this->clubeMapper = new ClubeMapper();
		$this->clubeService = new ClubeService();
	}

	public function listar(Request $request, Response $response, $args)
	{

		$clubes = $this->clubeDAO->list();
		$json = json_encode(
			$clubes,
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);

		$response->getBody()->write($json);

		return $response
			->withheader("content-type", "application/json")
			->withStatus(200);
	}

	public function inserir(Request $request, Response $response, $args)
	{
		$ClubeArrayAssoc = $request->getParsedBody();
		$clubes = $this->clubeMapper->mapFromJsonToObject($ClubeArrayAssoc);


		$erro = $this->clubeService->validar($clubes);
		if (!$erro) {
			try {

				$clube = $this->clubeDAO->insert($clubes);

				$response->getBody()->write(json_encode($clube, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

				return $response
					->withAddedHeader("content-type", "application/json")
					->withStatus(201);
			} catch (PDOException $e) {

				$erroJson = MensagemErro::getJSONErro($e->getCode(), $e->getMessage(), 500);

				$response->getBody()->write($erroJson);

				return $response
					->withAddedHeader("content-type", "application/json")
					->withStatus(500);
			}
		} else {
			$erroJson = MensagemErro::getJSONErro($erro, $erro, 400);

			$response->getBody()->write($erroJson);

			return $response
				->withStatus(400);
		}

		$response->getBody()->write(print_r($clubes, true));
		return $response;
	}

	public function buscar(Request $request, Response $response, $args)
	{

		//1 - receber o id ($args)
		$id = $args["id"];

		//2 - buscar o clube no banco de dados (DAO)
		$clube = $this->clubeDAO->findById($id);


		//3 - verificar se o clube foi encontrado
		$response->getBody()->write(json_encode($clube, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));



		//3.1 - SIM (retorna p JSON do clube e status 200)
		if ($clube) {
			return $response
				->withheader("content-type", "application/json")
				->withStatus(200);

			//3.2 - NÃO (retorna p JSON de erro e status 404)
		} else {

			return $response
				->withheader("content-type", "application/json")
				->withStatus(404);
		}
	}

	public function excluir(Request $request, Response $response, $args)
	{


		// 1 - receber o iddo clube ($args)
		$id = $args["id"];

		//2 - verificar se o clube existe (findById)
		$clube = $this->clubeDAO->findById($id);
		if ($clube) {

			//2.1 - se existe, Excluir -> status 200
			// - chamar o DAO para excluir ple id (TRY CATCH)

			try {

				$this->clubeDAO->deleteById($clube->getId());

				return $response
					->withAddedHeader("content-type", "application/json")
					->withStatus(200);
				

			} catch (PDOException $e) {

				return $response
					->withAddedHeader("content-type", "application/json")
					->withStatus(500);
			}
		} else {
		}
		return $response->withStatus(500);
	}


	public function alterar(Request $request, Response $response, $args){
		
	}
}
