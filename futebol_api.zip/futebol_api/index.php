<?php
//Habila os erros no php
ini_set('display_errors', 1);
error_reporting(E_ALL);

use App\Controller\ClubeController;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

//use App\Controller\ClubeController;
use Slim\Exception\HttpNotFoundException;

require_once(__DIR__ . '/vendor/autoload.php');

$app = AppFactory::create();
$app->setBasePath("/2_Semestre_Alexsandro/API/futebol_api"); //Adicionar o nome da pasta do projeto

// Parse json, form data and xml
$app->addBodyParsingMiddleware();
$app->addErrorMiddleware(true, true, true); //Retorna um erro do Framework caso não tratado

//ROTAS
$app->get('/', function (Request $request, Response $response, $args) {
    $response->getBody()->write("Funcionou!");
    return $response;
});

$app->get("/ola/{nome}", function (Request $request, Response $response, $args) {
    $nome = $args["nome"];
    $response->getBody()->write(" ola mundo ");
    $response->getBody()->write(" <br> seja bem  vindo " . $nome);
    return $response;
});

$app->get("/ola2 ", function (Request $request, Response $response, $args) {
    $parametros = $request->getQueryParams();

    $nome = "";
    if (isset($parametros["nome"]))

        if ($nome)
            $response->getBody()->write(" obrigado pelo seu acesso " . $nome);
        else
            $response->getBody()->write(" obrigado pelo seu acesso ");

    return $response;
});

//CLUBES
$app->get("/clubes", ClubeController::class . ":listar");
$app->get("/clubes/{id}", ClubeController::class . ":buscar");
$app->post("/clubes", ClubeController::class . ":inserir");
$app->delete("/clubes/{id}", ClubeController::class . ":excluir");
$app->put("/clubes/{id}", ClubeController::class . ":alterar");


//Tratamento para rota não encontrada
$app->map(['GET', 'POST', 'PUT', 'DELETE', 'PATCH'], '/{routes:.+}', function ($request, $response) {
    throw new HttpNotFoundException($request);
});

//Inicia a execução da aplicação (requisição)
$app->run();
